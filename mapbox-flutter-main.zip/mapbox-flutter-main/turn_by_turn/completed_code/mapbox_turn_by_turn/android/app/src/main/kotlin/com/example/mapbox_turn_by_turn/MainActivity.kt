package com.example.mapbox_turn_by_turn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
